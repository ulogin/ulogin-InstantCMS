<?php

class ulogin extends cmsFrontend {

	public static $is_profile;

}