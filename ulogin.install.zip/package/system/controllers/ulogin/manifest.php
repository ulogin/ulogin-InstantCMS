<?php

return array(

	'hooks' => array(
//		'user_auth_error',
		'users_profile_view',
	)

);