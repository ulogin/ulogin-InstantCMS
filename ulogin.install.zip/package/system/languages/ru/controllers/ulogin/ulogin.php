<?php

    define('LANG_ULOGIN_CONTROLLER',         'uLogin');
